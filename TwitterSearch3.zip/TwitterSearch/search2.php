<?php
	$json = file_get_contents('https://whatthetrend.com/articles?q=' . htmlspecialchars($_GET["q"]));

	$tweets = json_decode($json,true);

	print_r($tweets);

	$dates = array();
	for($i = 0; $i < count($tweets['articles']); $i++) {
		$date = DateTime::createFromFormat('D, d M Y H:i:s O', $tweets['articles'][$i]['date']);
		if(array_key_exists($date->format('Y-M-D'), $dates))
			$dates[$date->format('Y-M-D')]++;
		else
			$dates[$date->format('Y-M-D')] = 1;
		echo $tweets['articles'][$i]['text'] . "\r\n<br>";
	}

	echo "---------------------------------------\r\n<br>";
	print_r($dates);
?>

curl "https://stats.narshism.com/piwik.php?action_name=Search^%^20result^%^20for^%^20^%^22^%^20draintheswamp^%^22^%^20202^%^20Trend^%^20record^%^20^%^7C^%^20Twitter^%^20Trends^%^20Archive^%^20TrendoGate.com^&idsite=2^&rec=1^&r=459824^&h=10^&m=49^&s=48^&url=https^%^3A^%^2F^%^2Ftrendogate.com^%^2Fsearch^%^2F^%^3Ftrend^%^3Ddraintheswamp^&urlref=https^%^3A^%^2F^%^2Ftrendogate.com^%^2Fsearch^%^2F^%^3Ftrend^%^3Dtrump^&_id=623dabc6f02a4581^&_idts=1487432551^&_idvc=1^&_idn=0^&_refts=1487432551^&_viewts=1487432551^&_ref=https^%^3A^%^2F^%^2Fwww.quora.com^%^2FIs-there-an-archive-that-tracks-Twitter-Trending-Topics-historically^&send_image=1^&pdf=1^&qt=0^&realp=0^&wma=0^&dir=0^&fla=1^&java=0^&gears=0^&ag=0^&cookie=1^&res=4096x2160^&gt_ms=338" -H "DNT: 1" -H "Accept-Encoding: gzip, deflate, sdch, br" -H "Accept-Language: en-US,en;q=0.8" -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36" -H "Accept: image/webp,image/*,*/*;q=0.8" -H "Referer: https://trendogate.com/search/?trend=draintheswamp" -H "Connection: keep-alive" --compressed